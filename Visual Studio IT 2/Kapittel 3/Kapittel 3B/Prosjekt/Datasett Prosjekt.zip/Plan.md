# Plan for prosjekt

Her bare skriver jeg noen aktuelle mål og ser om jeg har gjort de. 

- Finn CSV data og gjør manuell analyse ✅
- Forklar Hver del, samt kontekst og betydning ✅


- Finn JSON og gjør pandas analyse ✅
- Forklar Hver del, samt kontekst og betydning. ✅

- Kilder? 🟡

- Skriv Forklaringen ✅