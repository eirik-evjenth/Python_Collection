# Logg for Datasett Prosjekt IT 2



## 6. Februar

### Hovedfokus:

Fokuset mitt for første dagen med dette prosjektet var å lære meg manuell analyse og pandas analyse. Gjorde manuell analyse av sykkeltur oppgaven (hadde allerede gjort en del bare fullførte og prøvde å forstå løsningsforslaget). Jeg brukte pandas for måltid CSV og klarte å lære en god del.

### Lærte:
- Mer spesifikt manuell analyse av data
- Pandas og mange av deres funksjoner

### Videre:
Skal analysere JSON og CSV filer med pandas og manuelt




## 10. Februar

### Hovedfokus:
Hovedfokuset var å gjøre analyse manuelt og med pandas for JSON og CSV filer. Jeg klarte det ganske bra, ingen store problemer. Noen problemer med filepath, men fikk det fikset.

### Lærte:
Analyse av JSON filer manuelt og med pandas.

### Videre:
Nå at jeg klarer å analysere hver type datasett så skal jeg finne et datasett eller to og analysere den.


## 13. Februar

### Hovedfokus:
Hovedfokuset var å finne data, kanskje komme igang med litt analyse. Jeg liker økonomi, derfor synes jeg det kan være vittig å se på aksjer. Så på dataen og gjorde litt basic analyse, alt fungerer fint, skrev litt om første data analyse delene hvor jeg plottet prisene over tid.

### Lærte:
Jeg brukte yfinance biblioteket og fant ut man kan bare få utrolig mye data fra det.
Var noen andre steder som Kaggle som hadde mye data man kunne gå i, skal sikkert bruke det senere.

### Videre:
Analysere dataen jeg har fått mer grundig, kanskje sammenlign det med andre aksjer. Må også finne en annen JSON fil og bruke Pandas for å analysere det.



## 17. Februar

### Hovedfokus:
Jeg ville ferdigstille CSV manuell analyse delen og forklaring. Klarte det godt, noen problemer som var lett å forstå/fikse, prøvde å inkludere både kode forklaring samt forklaring av de økonomiske aspektene, gir mening for meg nå, men noen må lese over.

### Lærte:
Jeg lærte veldig mye om økonomi og hvordan ytre faktorer har påvirket verdensøkonomien. Har vært spennende å utforske, hovedsakelig idag var skriving.

### Videre:
Finne JSON fil, analysere og forklare alt rundt der. Kaggle har alle aksjer på CSV og JSON, skal se der for en JSON fil om en annen teknologiskaksje som Nvidia. En medelev må lese gjennom det slik at jeg ser om de forstår alt. Må kanskje analysere mengde Apple som blir forvekslet i antall aksjer og pengesum sammenlignet med hele verdens forvekslinger.




## 20. Februar

### Hovedfokus:
Bli ferdig med alt koden for JSON filen, kanskje se litt på forklaringer men gjorde mitt beste å lage alt koden jeg synes var nødvendig. Ble ferdig med alt koden for JSON filene.

### Lærte:
Bruke Pandas og JSON, veldig nyttig og fint å lære hvordan å finne ting i en JSON fil og bruke pandas for å analysere det. Var ti ganger lettere.

### Videre:
Siden alt koden er på plass må jeg finjustere med kommentarer og se på koden. Samtidig å forklare alt som skjer er viktig, må se på det etter timen.
