with open("pb.txt", "w") as file:
    file.write("test")


# Jeg har ikke peiling om hvorfor dette skriver ikke til pb.txt
