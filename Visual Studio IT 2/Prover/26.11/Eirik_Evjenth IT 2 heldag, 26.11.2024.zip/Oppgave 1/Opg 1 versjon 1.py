# 1a

print("BMI-kalkulator")

vekt = 75 # kg
høyde = 175 # cm

høyde /= 100

BMI = vekt/(høyde*høyde)

print(f"BMI: {BMI}")